library(shiny)
library(shinyalert)
library(shinydashboard)
library(stringr)
library(bslib)

cmt <- read.csv("https://raw.githubusercontent.com/DavidBrocker/SPJ_443/main/443-Comments.csv")


ui <- dashboardPage(
  
  dashboardHeader(),
  
  dashboardSidebar(
    br(),
    actionButton(
      inputId = "btn",
      "Show Comments",
      icon = icon("message")
    )
  ),
  # Overall Rows
    dashboardBody(
      
      tags$style(".small-box{border-radius: 20px}"),
      tags$style(".talk-bubble{
                  margin: 40px;
                  display: inline-block;
                  position: relative;
                  width: 200px;
                  height: auto;
                  background-color: white;
                  }"),
      
      tags$style(".talk-text p{
                  -webkit-margin-before: 0em;
                 -webkit-margin-after: 0em;
                 }"),
      
      
  # Presentation Skills  
  fluidRow(
          valueBox(
          value = paste0(sample(1:5,1)),
          subtitle = "Presentation Skills",
          color = "aqua",
          icon = icon("person"),
          width = 3),
   
  # Visual 
      valueBox(
        value = paste0(sample(1:5,1)),
        subtitle = "Visual Skills",
        color = "yellow",
        icon = icon("eye"),
        width = 3)),
  fluidRow(
  # Content
        valueBox(
          value = paste0(sample(1:5,1)),
          subtitle = "Content",
          color = "red",
          icon = icon("list")),
      
  # Organization    
          valueBox(
            value = paste0(sample(1:5,1)),
            subtitle = "Organization",
            color = "orange",
            icon = icon("file"))
  ),
      
  # Overall Presentation    
  fluidRow(
            valueBox(
              value = paste0(sample(1:5,1)),
              subtitle = "Overall",
              color = "purple",
              icon = icon("thumbs-up")),
  # Time
          valueBox(
            value = "3:00",
            subtitle = "Duration",
            color = "blue",
            icon = icon("clock")
      )),
  HTML(paste0(
    "<div class = 'talk-bubble'>",
      "<div class = 'talk-text'>",
    "<p>",
        unlist(strsplit(cmt[5,2],"\\|")),
    "</p>",
    "</div>"),
    "</div>")
  
    )
  )

# Define server logic
server <- function(input, output) {

  
}

# Run the application 
shinyApp(ui = ui, server = server)

# Load Packages
library(stringr)
library(praise)
library(haven)
library(dplyr)
library(janitor)
library(labelled)

# Read in file
fdbk <- read_spss("feedback44324/443+Presentation+Feedback+S24_April+17,+2024_15.53.sav")

# Clean
fdbk_cln <- 
  fdbk %>% 
  clean_names() %>% 
  # Get Only 'Real' Responses
  filter(status == 0) %>% 
  # Remove unneeded columns
  select(!start_date:user_language)

# Summarize All Feedback
all_fdbk <- 
  fdbk_cln %>% 
  # Start with first section
  group_by(presenter_name_06) %>% 
  # Only get complete values
  filter(!is.na(presenter_name_06)) %>% 
  # Get Averages for each Skill by Presenter
  group_by(presenter_name_06) %>% 
  mutate(
    # Presentation Skills
    pres_skills1 = mean(presentation_skills_1),
    pres_skills2 = mean(presentation_skills_2),
    pres_skills3 = mean(presentation_skills_3),
    pres_skills4 = mean(presentation_skills_4),
    pres_skills5 = mean(presentation_skills_5),
    press_skills6 = mean(presentation_skills_6),
    pres_skills7 = mean(presentation_skills_7),
    # Visual Skills
    visual_skills1 = mean(visuals_1),
    visual_skill2 = mean(visuals_2),
    visual_skill3 = mean(visuals_3),
    visual_skill4 = mean(visuals_4),
    visual_skill5 = mean(visuals_5),
    visual_skill6 = mean(visuals_6),
    # Content
    content_skill1 = mean(content_1),
    content_skill2 = mean(content_2),
    content_skill3 = mean(content_3),
    content_skill4 = mean(content_4),
    content_skill5 = mean(content_5),
    # Organization
    organization_skill1 = mean(organization_1),
    organization_skill2 = mean(organization_2),
    organization_skill3 = mean(organization_3),
    organization_skill4 = mean(organization_4),
    organization_skill5 = mean(organization_5),
    organization_skill6 = mean(organization_6),
    # Overall Rating
    rating = mean(rating)
  ) %>% 
  # Group the data by row to get competency totals
  rowwise() %>%
  mutate(
    # Overall Presentation Skills
    pres_skills = mean(c_across(pres_skills1:pres_skills7)),
    # Overall Visual Skills
    visual_skills = mean(c_across(visual_skills1:visual_skill6)),
    # Overall Content
    content_skills = mean(c_across(content_skill1:content_skill5)),
    # Overall Organization
    organization = mean(c_across(organization_skill1:organization_skill6))) %>% 
  ungroup() %>% 
  select(presenter_name_06,comments,pres_skills,
         visual_skills,content_skills,organization,rating)

write.csv(all_fdbk, "summarized-feedback.csv")

sum_com <- 
  all_fdbk %>% 
  select(presenter_name_06,comments) %>%
  # Group by Presenter
  group_by(presenter_name_06) %>% 
  # Only look at complete comments
  filter(str_detect(comments,"^\\w")) %>% 
  mutate(all =  paste0(comments,collapse = "|")) %>% 
  select(presenter_name_06, all) %>% 
  distinct(all,.keep_all = T)

write.csv(sum_com,"all_comments.csv")

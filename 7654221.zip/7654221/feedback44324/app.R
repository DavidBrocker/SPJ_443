library(shiny)
library(stringr)
library(bslib)
library(bsicons)
library(praise)
library(haven)
library(dplyr)
library(janitor)
library(labelled)

# Read Files
all <- read.csv("summarized-feedback.csv")

com <- read.csv("all_comments.csv")

ui <- 
  page_sidebar(
    title = "443 Feedback",
    sidebar = sidebar(
      input_dark_mode(),
      sidebarSearchForm(textId = "name",
                        buttonId = "srch",
                        label = "Student ID")),
  layout_columns(
    fill = FALSE,
    # VB1
    value_box(
      title = "Presentation Skills",
      value = textOutput("pres"),
      showcase = bs_icon("check"),
      theme = "blue"),
     # VB2 
      value_box(
      title = "Visual Skills",
      value = textOutput("vis"),
      showcase = bs_icon("palette"),
      theme = "orange"
    ),
    # VB3
      value_box(
      title = "Content",
      value = textOutput("con"),
      showcase = bs_icon("card-list"),
      theme = "purple"
    ),
    # VB4
      value_box(
      title = "Organization",
      value = textOutput("org"),
      showcase = bs_icon("files"),
      theme = "red"
    ),
    # VB5
      value_box(
      title = "Overall Presentation",
      value = textOutput("rate"),
      showcase = bs_icon("hand-thumbs-up"),
      theme = "teal"
    ),
    #VB6
      value_box(
        id = "feed",
        value = "",
        showcase = bs_icon("chat-quote"),
        showcase_layout = "bottom",
        full_screen = TRUE,
        uiOutput("visual", fill = TRUE),
        theme = "yellow"
      )
  )
)

server <- function(input, output) {
  
  pressed <- eventReactive(input$srch, {
    input$name
  })
  
  observeEvent(pressed(), {
    
    student <- pressed()
  
  output$pres <- renderText({
    
    all_fdbk %>% 
      filter(presenter_name_06 == as.numeric(student)) %>% 
      select(pres_skills) %>% 
      unique() %>% 
      select(pres_skills) %>% 
      round(2) %>% as.character()
  })
  
  output$vis <- renderText({
    all_fdbk %>% 
      filter(presenter_name_06 == as.numeric(student)) %>% 
      select(visual_skills) %>% 
      unique() %>% 
      select(visual_skills) %>% 
      round(2) %>% as.character()
  })
  
  output$con <- renderText({
    all_fdbk %>% 
      filter(presenter_name_06 == as.numeric(student)) %>% 
      select(content_skills) %>% 
      unique() %>% 
      select(content_skills) %>% 
      round(2) %>% as.character()
  })
  
  output$org <- renderText({
    all_fdbk %>% 
      filter(presenter_name_06 == as.numeric(student)) %>% 
      select(organization) %>% 
      unique() %>% 
      select(organization) %>% 
      round(2) %>% as.character()
  })
  
  output$rate <- renderText({
    all_fdbk %>% 
      filter(presenter_name_06 == as.numeric(student)) %>% 
      select(rating) %>% 
      unique() %>% 
      select(rating) %>% 
      round(2) %>% as.character()
  })
  
  
  output$visual <- renderUI({
    if(input$feed_full_screen){
      tags$style("p{
                 font-size: 50px;
                 margin: 20px;
                 }")
   comments <- 
     com %>% 
     filter(presenter_name_06 == as.numeric(student)) %>% 
     select(all) %>% 
     as.character()
      
   HTML(
        paste0(
          "<p>",
           strsplit(comments,"\\|") %>% unlist() %>% str_to_sentence(),
           "</p>",
           "<br>")
      )
    } else{
      "Expand to view comments"
    }
  })
  
  })
}

shinyApp(ui, server)